package com.example.deepa.sharedpreference1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText name,age,city,phone;
    Button btn1,btn2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=(EditText) findViewById(R.id.editText2);
        age=(EditText) findViewById(R.id.editText3);
        phone=(EditText) findViewById(R.id.editText4);
        city=(EditText) findViewById(R.id.editText5);

        btn1=(Button)findViewById(R.id.button);
        btn2=(Button)findViewById(R.id.button2);




    }

    public void save(View view){
      SharedPreferences sharedPreferences=getSharedPreferences("MyData",MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();

        editor.putString("name",name.getText().toString());
        editor.putString("age",age.getText().toString());
        editor.putString("phone",phone.getText().toString());
        editor.putString("city",city.getText().toString());

        editor.commit();
        Toast.makeText(this,"Data Saved Successfully",Toast.LENGTH_LONG).show();

            name.setText("");
            age.setText("");
            phone.setText("");
            city.setText("");
    }

    public void show(View view){

        Intent intent=new Intent(this,SecondActivity.class);
        startActivity(intent);
    }
}
