package com.example.deepa.sharedpreference1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.String;

public class SecondActivity extends AppCompatActivity {
    TextView name1,age1,city1,phone1;

    Button btn1,btn2;
    public static final String DEFAULT="N/A";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);
        name1=(TextView) findViewById(R.id.editText2);
        age1=(TextView) findViewById(R.id.editText3);
        phone1=(TextView) findViewById(R.id.editText4);
        city1=(TextView) findViewById(R.id.editText5);

        btn1=(Button)findViewById(R.id.button);
        btn2=(Button)findViewById(R.id.button2);




    }

    public void  load(View view){
        SharedPreferences sharedPreferences=getSharedPreferences("MyData",MODE_PRIVATE);
        String name=sharedPreferences.getString("name",DEFAULT);
        String age=sharedPreferences.getString("age",DEFAULT);
        String phone=sharedPreferences.getString("phone",DEFAULT);
        String city=sharedPreferences.getString("city",DEFAULT);

        if(name.equals(DEFAULT) || age.equals(DEFAULT) || phone.equals(DEFAULT) || city.equals(DEFAULT))
            Toast.makeText(this,"NO DATA WAS FOUND",Toast.LENGTH_LONG).show();
            else
        {
            Toast.makeText(this," DATA LOADED SUCCESSFULLY",Toast.LENGTH_LONG).show();
            name1.setText(name);
            age1.setText(age);
            phone1.setText(phone);
            city1.setText(city);


        }

    }


    public void back(View view){

        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}
